<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Hello Denali!</title>
    <!-- Denali CSS & Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/denali-icon-font/dist/denali-icon-font.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/denali-css/css/denali.css">
  </head>
    <body style="background-image: url(bg.jpg); background-size: cover;">
        <nav class="nav">
            <div class="nav-left">
                <h3 style="position: absolute; color: rgba(255, 255, 255, 1.0); top: 50%; transform: translateY(-50%); width: 0px;"><i>KAFFEiROLLSBO.SE</i></h3>
                 <span class="nav-item" style="padding-left: 230px;"><i class="d-icon d-information-circle"></i></span>
            </div>
            <div class="nav-right nav-responive is-active">
               
            </div>
        </nav>
    <div class="container">
        <div class="row p-10 br-4">
            <div class="col p-10 br-4" style="background-color: #002B66">
                <div class="row p-10 br-4">
                    <div class="col p-10 br-4">
                        <div class="input">
                            <h1 style="color: white"><i>LOGGA IN:</i></h1>
                            <p style="color: rgba(0, 0, 0, 0.0);">_</p>
                            <input style="color: #002B66; background-color: white" class="" type="text" placeholder="USERNAME" />
                            <p style="color: rgba(0, 0, 0, 0.0);">_</p>
                            <input style="color: #002B66; background-color: white" type="text" placeholder="PASSWORD" />
                            <p style="color: rgba(0, 0, 0, 0.0);">_</p>
                            <button style="color: white" class="button is-outline"><i>SUBMIT</i></button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col p-10 br-4" style="background-color: #002B66">
                <div class="row p-10 br-4">
                    <div class="col p-10 br-4">
                        <div class="input">
                            <h1 style="color: white"><i>SKAPA KONTO:</i></h1>
                            <p style="color: rgba(0, 0, 0, 0.0);">_</p>
                            <input style="color: #002B66; background-color: white" class="" type="text" placeholder="USERNAME" />
                            <p style="color: rgba(0, 0, 0, 0.0);">_</p>
                            <input style="color: #002B66; background-color: white" class="" type="PASSWORD" placeholder="PASSWORD" />
                            <p style="color: rgba(0, 0, 0, 0.0);">_</p>
                            <input style="color: #002B66; background-color: white" class="" type="PASSWORD" placeholder="REPEAT" />
                            <p style="color: rgba(0, 0, 0, 0.0);">_</p>
                            <a href=""><button style="color: white" class="button is-outline"><i>SUBMIT</i></button></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>